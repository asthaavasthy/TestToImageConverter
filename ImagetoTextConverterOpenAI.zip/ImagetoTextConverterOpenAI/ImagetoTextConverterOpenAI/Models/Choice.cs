﻿using System.Text.Json.Serialization;


/// <summary>
///     Represents a choice in a conversation.
/// </summary>
/// <param name="Message"> The message associated with the choice. </param>
/// <param name="FinishDetails"> The details of the finish associated with the choice. </param>
/// <param name="Index"> The index of the choice. </param>

namespace ImagetoTextConverterOpenAI.Models
{
    internal record Choice(
     [property: JsonPropertyName("message")] Message? Message,
     [property: JsonPropertyName("finish_details")] FinishDetailInfo? FinishDetails,
     [property: JsonPropertyName("index")] int Index);

}
