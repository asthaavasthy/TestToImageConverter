﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace SampleUI.Models
{
    public class AIGenerative
    {
       // public int Id { get; set; }
        public string ConvertedText { get; set; }
       
        //[Required, Microsoft.Web.Mvc.FileExtensions(Extensions = "csv",
        //     ErrorMessage = "Specify a CSV file. (Comma-separated values)")]
        public IFormFile File { get; set; }

        public string Language { get; set; }

        [DisplayName("Upload File")]
        public string ImagePath { get; set; }

        [DisplayName("Choose Language")]
        public List<SelectListItem> Languages { get; set; }

        
    }
}
