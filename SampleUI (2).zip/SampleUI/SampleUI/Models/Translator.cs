﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace SampleUI.Models
{
    public class Translator
    {
       // public int Id { get; set; }
        public string ConvertedText { get; set; }

        public string FileName { get; set; }

        public string FullText { get; set; }
       
        //[Required, Microsoft.Web.Mvc.FileExtensions(Extensions = "csv",
        //     ErrorMessage = "Specify a CSV file. (Comma-separated values)")]
       
    }
}
